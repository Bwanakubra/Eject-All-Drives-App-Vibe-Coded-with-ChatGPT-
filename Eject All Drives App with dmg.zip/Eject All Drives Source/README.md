# Eject All Drives 1.1

Native macOS utility with a custom icon, a drag-to-Applications DMG, and arm64/Intel code. Requires macOS 13+. Quit version 1.0 before replacing it in Applications.

## What changed

The original version discovered disks through `diskutil list` and required optional hardware fields, including DeviceTreePath and TotalSize. Missing metadata or missing nested MountPoint values could silently exclude a mounted external SSD. The reported symptom was “No eligible mounted external drives were found”; the exact metadata returned by that SSD was not available in this session.

Version 1.1 starts with the native mounted-filesystem table using `getmntinfo(MNT_NOWAIT)`. It inspects each mounted local volume independently. Optional hardware fields are no longer eligibility requirements, and one volume's inspection failure no longer hides other drives. Skipped volumes and inspection errors appear in the results.

The requested broader scope now includes non-startup internal volumes, SMB/NFS/AFP/WebDAV/SSHFS network volumes, and offline macOS installations. The running startup system must remain mounted. Its mount paths and APFS container are protected, as is the volume from which this app is running. Other internal volumes sharing a physical disk are unmounted individually; the startup physical disk is never ejected as a whole.

## Behavior

The app immediately scans on launch. External APFS volumes are mapped to their physical stores and grouped for graceful whole-disk ejection when ancestry can be verified. Other physical external volumes can also be ejected as a whole. Internal volumes, virtual volumes, and volumes with incomplete ancestry use a single-volume unmount. Network shares use ordinary `umount` without force.

Results distinguish **Ejected**, **Unmounted**, **Disconnected**, **Protected**, and failures. A volume-only unmount does not imply that every other volume on the same disk has been unmounted. Unplug physical hardware only when all its volumes have been disconnected. A successful command is followed by a fresh mount-table check; a still-mounted or immediately remounted volume is reported as a failure.

Before each operation, a new snapshot must match the original mount identity (source, filesystem, mount path, kernel filesystem ID, and available volume UUID) and planned action. Mount table discovery and OS operations are separate calls; avoid swapping devices while a run is in progress.

No force flag, sudo, administrator helper, or network transmission is used. Permission denials and busy volumes remain connected and show the OS error. Multi-store APFS storage uses per-volume unmounts instead of ejecting one physical member. Unknown filesystems are reported rather than guessed. Protected system locations include /System, /private, /dev, /usr, /bin, /sbin, /Library, /Applications, and /Users; custom mounts within those locations remain protected.

**Eject Again** rescans. Clicking the Dock icon while idle also rescans. **Copy Results** copies volume labels and error details to your clipboard for troubleshooting; review that text before sharing it.

## Build and packaging

From this folder, with Apple's Command Line Tools installed:

```sh
./scripts/test.sh
./scripts/build.sh
./scripts/package-dmg.sh
```

Results are in `build/`. No third-party libraries are required. Open `Eject All Drives.xcodeproj` to build with full Xcode instead; choose My Mac. The scripts generate the custom ICNS icon, both CPU slices, the signed app, and the compressed DMG with an Applications shortcut. Packaging has a hybrid-HFS+ fallback for environments that cannot attach virtual disks.

This build is ad-hoc signed, not Apple Developer ID signed or notarized. Gatekeeper may require first-launch approval. For public distribution, use your own Developer ID certificate via `SIGN_IDENTITY`, submit with your own notarytool credentials, and staple the accepted ticket. Never disable Gatekeeper system-wide.

For a harmless UI demonstration, run the app executable with `--preview`; this does not inspect or disconnect volumes. `--preview --snapshot /absolute/path.png` additionally captures the view in a working desktop session. Normal launches perform actual disconnection.

## Verification limits

Regression tests exercise missing SSD metadata, APFS mapping, same-disk grouping, ExFAT, internal-volume unmounts, network shares, offline system installations, startup protection, the app's own volume, unknown storage, failed inspection, missing APFS inventory, multi-store storage, busy errors, mount replacement, and verifying disappearance after success. The native mount-table reader is also tested read-only in this environment.

The Apple compiler builds both architectures. Code signing and DMG checksums are verified. Full Xcode is unavailable; its project file is syntax-validated while the same sources are compiled through Command Line Tools.

This execution session cannot access DiskManagement or register a desktop application. Live UI layout, mounting the DMG, real SSD/internal/network unmounts, and Gatekeeper approval remain untested here. No actual volumes were disconnected during development. The toolchain emits an Intel compatibility-library warning, but linking succeeds; the intended M5 uses the arm64 slice.
