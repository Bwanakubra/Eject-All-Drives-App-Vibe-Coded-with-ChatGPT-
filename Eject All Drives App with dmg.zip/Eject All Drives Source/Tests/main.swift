import Foundation
var count = 0
func check(_ condition: @autoclosure () throws -> Bool, _ name: String) rethrows {
    let passed = try condition(); precondition(passed, "FAILED: " + name); count += 1
}
func mount(_ path: String, _ source: String, _ fs: String = "apfs", _ local: Bool = true, _ identity: String = "123") -> MountedVolume {
    MountedVolume(path: path, source: source, fs: fs, local: local, fsid: identity)
}
let root = mount("/", "/dev/disk3s1s1")
let data = mount("/System/Volumes/Data", "/dev/disk3s5")
let ssd = mount("/Volumes/SSD", "/dev/disk5s1")
let extra = mount("/Volumes/SSD 2", "/dev/disk5s2")
let share = mount("/Volumes/Shared Files", "//user@server/share", "smbfs", false)
let internalData = mount("/Volumes/Archive", "/dev/disk7s1")
let unknown = mount("/Volumes/Unknown", "/dev/disk8s1", "exfat")
let baseInfo: [String: [String: Any]] = [root.path: ["APFSContainerReference": "disk3"], data.path: ["APFSContainerReference": "disk3"], ssd.path: ["APFSContainerReference": "disk5", "Internal": false], extra.path: ["APFSContainerReference": "disk5", "Internal": false], internalData.path: ["APFSContainerReference": "disk7", "Internal": true]]
func container(_ ref: String, _ stores: [String]) -> [String: Any] { ["ContainerReference": ref, "PhysicalStores": stores.map { ["DeviceIdentifier": $0] }] }
let apfs: [String: Any] = ["Containers": [container("disk3", ["disk0s2"]), container("disk5", ["disk4s2"]), container("disk7", ["disk0s3"])]]
func snapshot(_ additional: [MountedVolume], _ info: [String: [String: Any]] = baseInfo, _ apfsInfo: [String: Any]? = apfs) throws -> DiskSnapshot {
    try DiskSafety.select(mounts: [root, data] + additional, infos: info, apfs: apfsInfo)
}
let selected = try snapshot([ssd])
check(selected.targets.count == 1, "SSD found without DeviceTreePath, TotalSize, VirtualOrPhysical or list MountPoint")
check(selected.targets[0].operation == .eject("disk4"), "APFS SSD mapped to physical disk")
check(selected.notices.contains { $0.protected }, "Running macOS explicitly reported protected")
try check(snapshot([]).targets.isEmpty, "Boot disk never selected")
let bootOther = mount("/Volumes/Boot Data", "/dev/disk3s5")
try check(snapshot([bootOther]).targets.isEmpty, "Boot container protected at alternative mount path")
try check(snapshot([internalData]).targets.first?.operation == .unmount(internalData.path), "Non-startup internal volume unmounted independently")
try check(snapshot([share]).targets.first?.operation == .network(share.path), "SMB share supported")
for fs in ["nfs", "afpfs", "webdav", "sshfs"] {
    try check(snapshot([mount("/Volumes/Network", "server:/share", fs, false)]).targets.count == 1, "Network \(fs) supported")
}
let grouped = try snapshot([ssd, extra])
check(grouped.targets.count == 1 && grouped.targets[0].paths.count == 2, "Same physical disk ejected once")
try check(snapshot([ssd], baseInfo, nil).targets.first?.operation == .unmount(ssd.path), "Missing APFS inventory permits safe volume unmount")
var partial = baseInfo; partial[unknown.path] = ["Internal": false]
try check(snapshot([unknown], partial).targets.first?.operation == .unmount(unknown.path), "Missing hardware metadata no longer silently hides drive")
let failure = try snapshot([unknown])
check(failure.targets.isEmpty && failure.notices.contains { !$0.protected }, "Inspection failure visible to user")
var multi = apfs; multi["Containers"] = [container("disk3", ["disk0s2"]), container("disk5", ["disk4s2", "disk6s2"])]
try check(snapshot([ssd], baseInfo, multi).targets.first?.operation == .unmount(ssd.path), "Multi-store volume unmounted without ejecting members")
var sharedPhysical = apfs; sharedPhysical["Containers"] = [container("disk3", ["disk0s2"]), container("disk5", ["disk0s3"])]
try check(snapshot([ssd], baseInfo, sharedPhysical).targets.first?.operation == .unmount(ssd.path), "No whole-disk eject on startup physical disk")
let clone = mount("/Volumes/Other macOS", "/dev/disk5s3")
var cloneInfo = baseInfo; cloneInfo[clone.path] = ["APFSContainerReference": "disk5", "Internal": false]
try check(snapshot([clone], cloneInfo).targets.count == 1, "Offline system installation eligible")
let pseudo = mount("/Volumes/automount", "map", "autofs", false)
try check(snapshot([pseudo]).targets.isEmpty, "Autofs pseudo filesystem excluded")
do { _ = try DiskSafety.select(mounts: [ssd], infos: baseInfo, apfs: apfs); fatalError("Missing root accepted") } catch { count += 1 }
let original = selected.targets[0]
var executable = ""; var args = [String]()
let result = try DiskSafety.eject(original, discoverer: { selected }, executor: { exe, arguments in
    executable = exe; args = arguments; return CommandResult(status: 0, output: "", data: Data())
}, mounted: { [root, data] })
check(executable == "/usr/sbin/diskutil" && args == ["eject", "disk4"], "Graceful physical eject without force")
check(result.hasPrefix("Ejected"), "Verified successful ejection")
for target in try snapshot([internalData, share]).targets {
    _ = try DiskSafety.eject(target, discoverer: { try snapshot([internalData, share]) }, executor: { exe, arguments in
        executable = exe; args = arguments; return CommandResult(status: 0, output: "", data: Data())
    }, mounted: { [root, data] })
    if case .network = target.operation { check(executable == "/sbin/umount" && args == [share.path], "Network unmount with literal spaced path") }
    else { check(args == ["unmount", internalData.path], "Internal volume never whole-disk eject") }
}
do {
    _ = try DiskSafety.eject(original, discoverer: { selected }, executor: { _, _ in CommandResult(status: 1, output: "busy", data: Data()) }, mounted: { [] })
    fatalError("Busy accepted")
} catch { check(error.localizedDescription.contains("Do not unplug"), "Busy failure retained") }
do {
    _ = try DiskSafety.eject(original, discoverer: { selected }, executor: { _, _ in CommandResult(status: 0, output: "", data: Data()) }, mounted: { [root, ssd] })
    fatalError("Still mounted accepted")
} catch { check(error.localizedDescription.contains("still mounted"), "Success requires actual disappearance") }
var ran = false
let replacement = mount(ssd.path, ssd.source, "apfs", true, "different-fsid")
do {
    _ = try DiskSafety.eject(original, discoverer: { try snapshot([replacement]) }, executor: { _, _ in ran = true; return CommandResult(status: 0, output: "", data: Data()) }, mounted: { [] })
    fatalError("Replacement accepted")
} catch { check(!ran, "Changed mount identity prevents ejection") }
var fatInfo = baseInfo; fatInfo[unknown.path] = ["Internal": false, "VirtualOrPhysical": "Physical"]
try check(snapshot([unknown], fatInfo).targets.first?.operation == .eject("disk8"), "ExFAT SSD without device tree path is ejected")
let appProtected = try DiskSafety.select(mounts: [root, data, ssd], infos: baseInfo, apfs: apfs, appPath: "/Volumes/SSD/Eject All Drives.app")
check(appProtected.targets.isEmpty && appProtected.notices.contains { $0.detail.contains("app is running") }, "Never disconnect the app's own volume")
let realMounts = try DiskSafety.mountedVolumes()
check(!realMounts.isEmpty, "Native mount-table read succeeds")
print("Passed \(count) safety and regression checks. No real volumes were unmounted.")
