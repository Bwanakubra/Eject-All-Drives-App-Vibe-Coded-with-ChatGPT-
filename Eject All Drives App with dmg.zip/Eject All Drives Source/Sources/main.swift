import AppKit

final class AppDelegate: NSObject, NSApplicationDelegate {
    var window: NSWindow!
    var titleLabel: NSTextField!
    var subtitle: NSTextField!
    var rows: NSStackView!
    var button: NSButton!
    var spinner: NSProgressIndicator!
    var busy = false
    var report = ""
    func label(_ text: String, size: CGFloat = 14, weight: NSFont.Weight = .regular, color: NSColor = .labelColor) -> NSTextField {
        let label = NSTextField(wrappingLabelWithString: text)
        label.font = .systemFont(ofSize: size, weight: weight)
        label.textColor = color
        return label
    }
    func applicationDidFinishLaunching(_ notification: Notification) {
        let menu = NSMenu()
        let item = NSMenuItem(); menu.addItem(item)
        let appMenu = NSMenu(); item.submenu = appMenu
        appMenu.addItem(withTitle: "About Eject All Drives", action: #selector(NSApplication.orderFrontStandardAboutPanel(_:)), keyEquivalent: "")
        appMenu.addItem(.separator())
        appMenu.addItem(withTitle: "Quit Eject All Drives", action: #selector(NSApplication.terminate(_:)), keyEquivalent: "q")
        NSApp.mainMenu = menu
        window = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 580, height: 490), styleMask: [.titled, .closable, .miniaturizable, .resizable], backing: .buffered, defer: false)
        window.title = "Eject All Drives"
        window.minSize = NSSize(width: 480, height: 390)
        window.titlebarAppearsTransparent = true
        window.isReleasedWhenClosed = false
        let content = window.contentView!
        let stack = NSStackView(); stack.orientation = .vertical; stack.alignment = .leading; stack.spacing = 16
        stack.translatesAutoresizingMaskIntoConstraints = false
        content.addSubview(stack)
        NSLayoutConstraint.activate([stack.leadingAnchor.constraint(equalTo: content.leadingAnchor, constant: 28), stack.trailingAnchor.constraint(equalTo: content.trailingAnchor, constant: -28), stack.topAnchor.constraint(equalTo: content.topAnchor, constant: 22), stack.bottomAnchor.constraint(equalTo: content.bottomAnchor, constant: -24)])
        let heading = NSStackView(); heading.spacing = 16
        let icon = NSImageView(image: NSApp.applicationIconImage); icon.imageScaling = .scaleProportionallyUpOrDown
        icon.widthAnchor.constraint(equalToConstant: 64).isActive = true; icon.heightAnchor.constraint(equalToConstant: 64).isActive = true
        heading.addArrangedSubview(icon)
        let headingText = NSStackView(); headingText.orientation = .vertical; headingText.alignment = .leading; headingText.spacing = 5
        titleLabel = label("Getting ready…", size: 25, weight: .bold)
        headingText.addArrangedSubview(titleLabel)
        headingText.addArrangedSubview(label("One click. A safe disconnect.", color: .secondaryLabelColor))
        heading.addArrangedSubview(headingText); stack.addArrangedSubview(heading)
        subtitle = label("Checking mounted volumes…", color: .secondaryLabelColor)
        stack.addArrangedSubview(subtitle)
        let scroll = NSScrollView(); scroll.hasVerticalScroller = true; scroll.drawsBackground = false
        scroll.translatesAutoresizingMaskIntoConstraints = false
        rows = NSStackView(); rows.orientation = .vertical; rows.alignment = .leading; rows.spacing = 12
        rows.translatesAutoresizingMaskIntoConstraints = false
        let document = NSView(); document.translatesAutoresizingMaskIntoConstraints = false
        scroll.documentView = document; document.addSubview(rows)
        NSLayoutConstraint.activate([document.widthAnchor.constraint(equalTo: scroll.contentView.widthAnchor), rows.leadingAnchor.constraint(equalTo: document.leadingAnchor), rows.trailingAnchor.constraint(equalTo: document.trailingAnchor, constant: -8), rows.topAnchor.constraint(equalTo: document.topAnchor, constant: 4), rows.bottomAnchor.constraint(equalTo: document.bottomAnchor, constant: -8)])
        stack.addArrangedSubview(scroll); scroll.widthAnchor.constraint(equalTo: stack.widthAnchor).isActive = true
        scroll.heightAnchor.constraint(greaterThanOrEqualToConstant: 150).isActive = true
        stack.addArrangedSubview(label("External drives, non-startup internal volumes, and network shares. The running macOS system stays mounted. Busy volumes are never forced.", size: 12, color: .secondaryLabelColor))
        let footer = NSStackView(); footer.spacing = 12
        spinner = NSProgressIndicator(); spinner.style = .spinning; spinner.controlSize = .small; spinner.isDisplayedWhenStopped = false
        footer.addArrangedSubview(spinner)
        button = NSButton(title: "Eject Again", target: self, action: #selector(start)); button.bezelStyle = .rounded
        footer.addArrangedSubview(button)
        let copy = NSButton(title: "Copy Results", target: self, action: #selector(copyResults)); copy.bezelStyle = .rounded
        footer.addArrangedSubview(copy); stack.addArrangedSubview(footer)
        window.center(); window.makeKeyAndOrderFront(nil); NSApp.activate(ignoringOtherApps: true)
        if CommandLine.arguments.contains("--preview") {
            titleLabel.stringValue = "Some drives need attention"
            subtitle.stringValue = "2 of 3 drives ejected. Review the results below."
            _ = addRow("Travel SSD", detail: "Ejected — Safe to disconnect.", symbol: "checkmark.circle.fill", color: .systemGreen)
            _ = addRow("Camera SD", detail: "Ejected — Safe to disconnect.", symbol: "checkmark.circle.fill", color: .systemGreen)
            _ = addRow("Backup Drive", detail: "Not ejected — A file is in use. Close apps or files using this drive, then try again. Do not unplug it yet.", symbol: "exclamationmark.triangle.fill", color: .systemOrange)
            button.title = "Preview only"; button.isEnabled = false
            if let index = CommandLine.arguments.firstIndex(of: "--snapshot"), CommandLine.arguments.count > index + 1 {
                window.contentView!.layoutSubtreeIfNeeded()
                let view = window.contentView!
                if let bitmap = view.bitmapImageRepForCachingDisplay(in: view.bounds) {
                    view.cacheDisplay(in: view.bounds, to: bitmap)
                    try? bitmap.representation(using: .png, properties: [:])?.write(to: URL(fileURLWithPath: CommandLine.arguments[index+1]))
                }
                NSApp.terminate(nil)
            }
        } else { start() }
    }
    func addRow(_ text: String, detail: String, symbol: String, color: NSColor) -> NSTextField {
        let line = NSStackView(); line.alignment = .top; line.spacing = 10
        let icon = NSImageView(image: NSImage(systemSymbolName: symbol, accessibilityDescription: nil) ?? NSImage())
        icon.contentTintColor = color; icon.widthAnchor.constraint(equalToConstant: 22).isActive = true
        line.addArrangedSubview(icon)
        let texts = NSStackView(); texts.orientation = .vertical; texts.alignment = .leading; texts.spacing = 3
        texts.addArrangedSubview(label(text, weight: .semibold))
        let detailLabel = label(detail, size: 12, color: .secondaryLabelColor); texts.addArrangedSubview(detailLabel)
        line.addArrangedSubview(texts); rows.addArrangedSubview(line)
        line.widthAnchor.constraint(equalTo: rows.widthAnchor).isActive = true
        return detailLabel
    }
    @objc func start() {
        guard !busy else { return }; busy = true; button.isEnabled = false; spinner.startAnimation(nil)
        for view in rows.arrangedSubviews { rows.removeArrangedSubview(view); view.removeFromSuperview() }
        titleLabel.stringValue = "Checking drives…"; subtitle.stringValue = "Finding local and network volumes."
        report = "Eject All Drives 1.1\n"
        DispatchQueue.global(qos: .userInitiated).async {
            do {
                let snapshot = try DiskSafety.discover()
                let targets = snapshot.targets
                DispatchQueue.main.sync {
                    self.titleLabel.stringValue = targets.isEmpty ? "No drives to eject" : "Ejecting safely…"
                    self.subtitle.stringValue = targets.isEmpty ? "No removable volumes found. See protected or skipped items below." : "Keep drives connected until their result appears."
                    for notice in snapshot.notices {
                        _ = self.addRow(notice.name, detail: notice.detail, symbol: notice.protected ? "lock.shield" : "exclamationmark.triangle", color: notice.protected ? .secondaryLabelColor : .systemOrange)
                        self.report += "\(notice.name): \(notice.detail)\n"
                    }
                }
                var failures = snapshot.notices.filter { !$0.protected }.count
                var completed = 0
                for target in targets {
                    var row: NSTextField!
                    DispatchQueue.main.sync { row = self.addRow(target.volumes.joined(separator: ", "), detail: "Disconnecting \(target.id)…", symbol: "externaldrive", color: .controlAccentColor) }
                    do {
                        let message = try DiskSafety.eject(target)
                        completed += 1
                        DispatchQueue.main.sync { row.stringValue = message; row.textColor = .systemGreen; self.report += "\(target.volumes.joined(separator: ", ")): \(message)\n" }
                    } catch {
                        failures += 1
                        let message = error.localizedDescription
                        DispatchQueue.main.sync { row.stringValue = "Not disconnected — " + message; row.textColor = .systemOrange; self.report += "\(target.volumes.joined(separator: ", ")) [\(target.id)]: \(message)\n" }
                    }
                }
                let failureCount = failures
                let completedCount = completed
                DispatchQueue.main.async {
                    if !targets.isEmpty || failureCount > 0 {
                        self.titleLabel.stringValue = failureCount == 0 ? "All clear" : "Some drives need attention"
                        self.subtitle.stringValue = "\(completedCount) of \(targets.count) targets disconnected." + (failureCount > 0 ? " Review the issues below." : " System volumes remain protected.")
                    }
                    self.finish()
                }
            } catch {
                let message = error.localizedDescription
                DispatchQueue.main.async {
                    self.titleLabel.stringValue = "Couldn’t check drives"
                    self.subtitle.stringValue = "Nothing was ejected. You can try again."
                    self.report += message
                    _ = self.addRow("Disk inventory unavailable", detail: message, symbol: "exclamationmark.triangle", color: .systemOrange)
                    self.finish()
                }
            }
        }
    }
    @objc func copyResults() { NSPasteboard.general.clearContents(); NSPasteboard.general.setString(report, forType: .string) }
    func finish() { busy = false; button.isEnabled = true; spinner.stopAnimation(nil) }
    func applicationShouldTerminate(_ sender: NSApplication) -> NSApplication.TerminateReply {
        if busy { NSSound.beep(); return .terminateCancel }; return .terminateNow
    }
    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool { !busy }
    func applicationShouldHandleReopen(_ sender: NSApplication, hasVisibleWindows flag: Bool) -> Bool {
        window.makeKeyAndOrderFront(nil)
        if !busy && !CommandLine.arguments.contains("--preview") { start() }
        return true
    }
}
let app = NSApplication.shared
let delegate = AppDelegate()
app.delegate = delegate
app.setActivationPolicy(.regular)
app.run()
