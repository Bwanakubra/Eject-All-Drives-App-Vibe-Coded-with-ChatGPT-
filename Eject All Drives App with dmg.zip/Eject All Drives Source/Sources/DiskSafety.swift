import Foundation
import Darwin

struct CommandResult { let status: Int32; let output: String; let data: Data }
func runCommand(_ executable: String, _ arguments: [String]) throws -> CommandResult {
    let process = Process()
    process.executableURL = URL(fileURLWithPath: executable)
    process.arguments = arguments
    let pipe = Pipe(); process.standardOutput = pipe; process.standardError = pipe
    try process.run()
    let data = pipe.fileHandleForReading.readDataToEndOfFile()
    process.waitUntilExit()
    return CommandResult(status: process.terminationStatus, output: String(data: data, encoding: .utf8) ?? "", data: data)
}
func diskutil(_ arguments: [String]) throws -> CommandResult { try runCommand("/usr/sbin/diskutil", arguments) }
func plist(_ arguments: [String]) throws -> [String: Any] {
    let result = try diskutil(arguments)
    guard result.status == 0 else { throw SafetyError.message(result.output.trimmingCharacters(in: .whitespacesAndNewlines)) }
    guard let dict = try PropertyListSerialization.propertyList(from: result.data, format: nil) as? [String: Any] else {
        throw SafetyError.message("macOS returned an unreadable disk inventory.")
    }
    return dict
}
enum SafetyError: LocalizedError {
    case message(String)
    var errorDescription: String? { if case .message(let text) = self { return text }; return nil }
}
struct MountedVolume {
    let path: String
    let source: String
    let fs: String
    let local: Bool
    let fsid: String
    var device: String? {
        guard source.hasPrefix("/dev/") else { return nil }
        let value = String(source.dropFirst(5))
        return value.range(of: "^disk[0-9]+(s[0-9]+)*$", options: .regularExpression) != nil ? value : nil
    }
    var identity: String { "\(path)|\(source)|\(fs)|\(fsid)" }
    var name: String { path == "/" ? "macOS startup volume" : URL(fileURLWithPath: path).lastPathComponent }
}
enum Operation: Equatable { case eject(String), unmount(String), network(String) }
struct TargetDisk {
    let id: String
    let name: String
    let volumes: [String]
    let identity: String
    let operation: Operation
    let paths: [String]
}
struct DiskNotice { let name: String; let detail: String; let protected: Bool }
struct DiskSnapshot { var targets: [TargetDisk]; var notices: [DiskNotice] }

enum DiskSafety {
    static func mountedVolumes() throws -> [MountedVolume] {
        var buffer: UnsafeMutablePointer<statfs>?
        let count = getmntinfo(&buffer, MNT_NOWAIT)
        guard count > 0, let buffer = buffer else { throw SafetyError.message("Could not read the macOS mount table.") }
        func string<T>(_ tuple: inout T) -> String {
            withUnsafePointer(to: &tuple) { pointer in
                pointer.withMemoryRebound(to: CChar.self, capacity: MemoryLayout<T>.size) { String(cString: $0) }
            }
        }
        return (0..<Int(count)).map { index in
            var entry = buffer[index]
            return MountedVolume(path: string(&entry.f_mntonname), source: string(&entry.f_mntfromname), fs: string(&entry.f_fstypename), local: entry.f_flags & UInt32(MNT_LOCAL) != 0, fsid: "\(entry.f_fsid.val.0):\(entry.f_fsid.val.1)")
        }
    }
    static func wholeID(_ id: String) -> String? {
        guard id.range(of: "^disk[0-9]+(s[0-9]+)*$", options: .regularExpression) != nil,
              let range = id.range(of: "^disk[0-9]+", options: .regularExpression) else { return nil }
        return String(id[range])
    }
    static func systemMount(_ path: String) -> Bool {
        path == "/" || ["/System", "/private", "/dev", "/usr", "/bin", "/sbin", "/Library", "/Applications", "/Users"].contains { path == $0 || path.hasPrefix($0 + "/") }
    }
    static func select(mounts: [MountedVolume], infos: [String: [String: Any]], apfs: [String: Any]?, errors: [String: String] = [:], appPath: String = Bundle.main.bundleURL.path) throws -> DiskSnapshot {
        guard mounts.contains(where: { $0.path == "/" && $0.device != nil }) else {
            throw SafetyError.message("Could not identify the running macOS startup disk. Nothing was ejected.")
        }
        var storesByContainer = [String: [String]]()
        for container in apfs?["Containers"] as? [[String: Any]] ?? [] {
            guard let ref = container["ContainerReference"] as? String,
                  let stores = container["PhysicalStores"] as? [[String: Any]] else { continue }
            let ids = stores.compactMap { ($0["DeviceIdentifier"] as? String).flatMap(wholeID) }
            if ids.count == stores.count && !ids.isEmpty { storesByContainer[ref] = Array(Set(ids)) }
        }
        func container(_ mount: MountedVolume) -> String? {
            if let ref = infos[mount.path]?["APFSContainerReference"] as? String { return ref }
            return mount.device.flatMap(wholeID)
        }
        let protectedContainers = Set(mounts.filter { systemMount($0.path) || ($0.path != "/" && appPath.hasPrefix($0.path + "/")) }.compactMap(container))
        var protectedPhysical = Set<String>()
        for ref in protectedContainers { protectedPhysical.formUnion(storesByContainer[ref] ?? [ref]) }
        // If APFS ancestry is unknown, do not eject any whole disk. Per-volume unmounts
        // are still safe because protected mounts/containers are excluded independently.
        let canEjectWhole = mounts.filter { (systemMount($0.path) || ($0.path != "/" && appPath.hasPrefix($0.path + "/"))) && $0.fs == "apfs" }.allSatisfy {
            guard let ref = container($0) else { return false }; return storesByContainer[ref] != nil
        }
        var targets = [TargetDisk](); var notices = [DiskNotice]()
        let networkTypes: Set<String> = ["smbfs", "nfs", "afpfs", "webdav", "cifs", "sshfs"]
        for mount in mounts {
            if mount.path != "/" && appPath.hasPrefix(mount.path + "/") {
                notices.append(DiskNotice(name: mount.name, detail: "Protected — this app is running from this volume. Install it in Applications, then launch the installed copy.", protected: true))
                continue
            }
            if systemMount(mount.path) || (container(mount).map { protectedContainers.contains($0) } ?? false) {
                // Hide macOS helper mounts but always show the running system explicitly.
                if mount.path == "/" || mount.path.hasPrefix("/Volumes/") {
                    notices.append(DiskNotice(name: mount.name, detail: "Protected — part of the running macOS startup system. It must stay mounted while this Mac is running.", protected: true))
                }
                continue
            }
            if networkTypes.contains(mount.fs) && !mount.local {
                targets.append(TargetDisk(id: mount.path, name: mount.name, volumes: [mount.name], identity: mount.identity, operation: .network(mount.path), paths: [mount.path]))
                continue
            }
            guard mount.device != nil else {
                if mount.path.hasPrefix("/Volumes/") {
                    notices.append(DiskNotice(name: mount.name, detail: "Skipped — unsupported filesystem (\(mount.fs)); no unmount was attempted.", protected: false))
                }
                continue
            }
            guard let info = infos[mount.path] else {
                notices.append(DiskNotice(name: mount.name, detail: "Could not inspect this mounted volume: " + (errors[mount.path] ?? "macOS returned no disk details."), protected: false)); continue
            }
            // Mount table is authoritative for presence. DeviceTreePath, TotalSize,
            // VirtualOrPhysical and list-plist MountPoint are NOT prerequisites.
            let ref = container(mount)
            let isAPFS = mount.fs == "apfs"
            let physical = isAPFS ? ref.flatMap { storesByContainer[$0] } : mount.device.flatMap(wholeID).map { [$0] }
            let external = info["Internal"] as? Bool == false
            var op: Operation = .unmount(mount.path)
            if external, canEjectWhole, let physical = physical, physical.count == 1,
               !protectedPhysical.contains(physical[0]),
               (isAPFS || info["VirtualOrPhysical"] as? String == "Physical") {
                op = .eject(physical[0])
            }
            let key: String
            if case .eject(let id) = op { key = id } else { key = mount.path }
            let identity = mount.identity + "|" + (info["VolumeUUID"] as? String ?? "")
            if let index = targets.firstIndex(where: { $0.id == key }) {
                let old = targets[index]
                targets[index] = TargetDisk(id: key, name: old.name, volumes: old.volumes + [mount.name], identity: old.identity + "\n" + identity, operation: op, paths: old.paths + [mount.path])
            } else {
                targets.append(TargetDisk(id: key, name: mount.name, volumes: [mount.name], identity: identity, operation: op, paths: [mount.path]))
            }
        }
        return DiskSnapshot(targets: targets, notices: notices)
    }
    static func discover() throws -> DiskSnapshot {
        let mounts = try mountedVolumes().sorted { $0.path < $1.path }
        var infos = [String: [String: Any]](); var errors = [String: String]()
        for mount in mounts where mount.device != nil {
            do { infos[mount.path] = try plist(["info", "-plist", mount.path]) }
            catch { errors[mount.path] = error.localizedDescription }
        }
        // An unavailable APFS inventory disables whole-disk ejection, not all discovery.
        return try select(mounts: mounts, infos: infos, apfs: try? plist(["apfs", "list", "-plist"]), errors: errors)
    }
    static func eject(_ original: TargetDisk, discoverer: () throws -> DiskSnapshot = { try discover() }, executor: (String, [String]) throws -> CommandResult = runCommand, mounted: () throws -> [MountedVolume] = { try mountedVolumes() }) throws -> String {
        let current = try discoverer()
        guard let target = current.targets.first(where: { $0.id == original.id }), target.identity == original.identity, target.operation == original.operation else {
            throw SafetyError.message("The volume changed, disconnected, or became protected. Skipped; scan again.")
        }
        let result: CommandResult
        let success: String
        switch target.operation {
        case .eject(let disk):
            result = try executor("/usr/sbin/diskutil", ["eject", disk])
            success = "Ejected — Safe to disconnect."
        case .unmount(let path):
            result = try executor("/usr/sbin/diskutil", ["unmount", path])
            success = "Unmounted — this volume is disconnected."
        case .network(let path):
            // umount supports network mounts; no -f, sudo, shell, or privileged helper.
            result = try executor("/sbin/umount", [path])
            success = "Disconnected — network volume unmounted."
        }
        guard result.status == 0 else {
            throw SafetyError.message(result.output.trimmingCharacters(in: .whitespacesAndNewlines) + "\nClose apps or files using this volume, then try again. Do not unplug it yet.")
        }
        let remaining = try mounted()
        guard !remaining.contains(where: { target.paths.contains($0.path) }) else {
            throw SafetyError.message("macOS reported success, but this volume is still mounted or was remounted. Do not unplug it; scan again.")
        }
        return success
    }
}
