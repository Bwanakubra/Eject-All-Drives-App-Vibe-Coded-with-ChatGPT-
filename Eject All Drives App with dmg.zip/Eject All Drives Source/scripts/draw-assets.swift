import AppKit
let destination = CommandLine.arguments[1]
let fm = FileManager.default
try fm.createDirectory(atPath: destination + "/AppIcon.iconset", withIntermediateDirectories: true)
func render(_ size: Int) -> Data {
    let bitmap = NSBitmapImageRep(bitmapDataPlanes: nil, pixelsWide: size, pixelsHigh: size, bitsPerSample: 8, samplesPerPixel: 4, hasAlpha: true, isPlanar: false, colorSpaceName: .deviceRGB, bytesPerRow: 0, bitsPerPixel: 0)!
    let context = NSGraphicsContext(bitmapImageRep: bitmap)!
    NSGraphicsContext.saveGraphicsState(); NSGraphicsContext.current = context
    let c = context.cgContext; c.scaleBy(x: CGFloat(size)/1024, y: CGFloat(size)/1024)
    let tile = NSBezierPath(roundedRect: NSRect(x: 72, y: 72, width: 880, height: 880), xRadius: 196, yRadius: 196)
    let shadow = NSShadow(); shadow.shadowColor = NSColor.black.withAlphaComponent(0.25); shadow.shadowBlurRadius = 32; shadow.shadowOffset = NSSize(width: 0, height: -16); shadow.set()
    NSColor(calibratedRed: 0.03, green: 0.14, blue: 0.24, alpha: 1).setFill(); tile.fill()
    NSShadow().set()
    NSGradient(colors: [NSColor(calibratedRed: 0.035, green: 0.15, blue: 0.29, alpha: 1), NSColor(calibratedRed: 0.05, green: 0.52, blue: 0.64, alpha: 1)])!.draw(in: tile, angle: 65)
    NSColor.white.withAlphaComponent(0.18).setStroke(); tile.lineWidth = 3; tile.stroke()
    let tray = NSBezierPath(roundedRect: NSRect(x: 239, y: 230, width: 546, height: 116), xRadius: 38, yRadius: 38)
    NSColor.white.withAlphaComponent(0.94).setFill(); tray.fill()
    let triangle = NSBezierPath(); triangle.move(to: NSPoint(x: 512, y: 771)); triangle.line(to: NSPoint(x: 784, y: 424)); triangle.curve(to: NSPoint(x: 762, y: 386), controlPoint1: NSPoint(x: 800, y: 402), controlPoint2: NSPoint(x: 788, y: 386)); triangle.line(to: NSPoint(x: 262, y: 386)); triangle.curve(to: NSPoint(x: 240, y: 424), controlPoint1: NSPoint(x: 236, y: 386), controlPoint2: NSPoint(x: 224, y: 402)); triangle.close()
    NSGradient(colors: [NSColor(calibratedRed: 0.98, green: 0.72, blue: 0.26, alpha: 1), NSColor(calibratedRed: 1, green: 0.93, blue: 0.62, alpha: 1)])!.draw(in: triangle, angle: 90)
    NSColor(calibratedRed: 0.02, green: 0.33, blue: 0.40, alpha: 1).setFill()
    NSBezierPath(roundedRect: NSRect(x: 670, y: 270, width: 62, height: 32), xRadius: 16, yRadius: 16).fill()
    NSGraphicsContext.restoreGraphicsState()
    return bitmap.representation(using: .png, properties: [:])!
}
for size in [16,32,128,256,512] {
    try render(size).write(to: URL(fileURLWithPath: destination + "/AppIcon.iconset/icon_\(size)x\(size).png"))
    try render(size*2).write(to: URL(fileURLWithPath: destination + "/AppIcon.iconset/icon_\(size)x\(size)@2x.png"))
}
try render(1024).write(to: URL(fileURLWithPath: destination + "/Icon Preview.png"))
// Standard ICNS container with PNG representations (including Retina variants).
func be32(_ value: Int) -> Data { var n = UInt32(value).bigEndian; return withUnsafeBytes(of: &n) { Data($0) } }
var chunks = Data()
for (type, size) in [("icp4",16),("icp5",32),("icp6",64),("ic07",128),("ic08",256),("ic09",512),("ic10",1024),("ic11",32),("ic12",64),("ic13",256),("ic14",512)] {
    let png = render(size); chunks.append(type.data(using: .ascii)!); chunks.append(be32(png.count + 8)); chunks.append(png)
}
var icns = "icns".data(using: .ascii)!; icns.append(be32(chunks.count + 8)); icns.append(chunks)
try icns.write(to: URL(fileURLWithPath: destination + "/AppIcon.icns"))
