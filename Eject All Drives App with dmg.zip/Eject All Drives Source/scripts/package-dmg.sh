#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD="$ROOT/build"
APP="$BUILD/Eject All Drives.app"
[ -d "$APP" ] || "$ROOT/scripts/build.sh"
STAGE="$(mktemp -d "$BUILD/dmg-stage.XXXXXX")"
trap 'rm -rf "$STAGE"' EXIT
ditto "$APP" "$STAGE/Eject All Drives.app"
ln -s /Applications "$STAGE/Applications"
cp "$ROOT/Install.txt" "$STAGE/Install.txt"
cp "$APP/Contents/Resources/AppIcon.icns" "$STAGE/.VolumeIcon.icns"
# The app is ready to drag to Applications; no installer or administrator helper is used.
if ! hdiutil create -volname 'Eject All Drives' -srcfolder "$STAGE" -ov -format UDZO "$BUILD/Eject All Drives.dmg"; then
    # This route can build HFS+ without attaching a virtual disk in restricted sessions.
    hdiutil makehybrid -hfs -hfs-volume-name 'Eject All Drives' -hfs-openfolder "$STAGE" -o "$BUILD/EjectAllDrives-hybrid.dmg" "$STAGE" -ov
    hdiutil convert "$BUILD/EjectAllDrives-hybrid.dmg" -format UDZO -o "$BUILD/Eject All Drives.dmg" -ov
    rm -f "$BUILD/EjectAllDrives-hybrid.dmg"
fi
hdiutil verify "$BUILD/Eject All Drives.dmg"
printf 'Packaged: %s\n' "$BUILD/Eject All Drives.dmg"
