#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
BUILD="$ROOT/build"
APP="$BUILD/Eject All Drives.app"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources" "$BUILD/module-cache"
export CLANG_MODULE_CACHE_PATH="$BUILD/module-cache"
export SWIFT_MODULECACHE_PATH="$BUILD/module-cache"
xcrun swift "$ROOT/scripts/draw-assets.swift" "$BUILD"
cp "$BUILD/AppIcon.icns" "$APP/Contents/Resources/AppIcon.icns"
for ARCH in arm64 x86_64; do
    xcrun swiftc -O -swift-version 5 -target "$ARCH-apple-macosx13.0" -framework AppKit \
        "$ROOT/Sources/DiskSafety.swift" "$ROOT/Sources/main.swift" -o "$BUILD/EjectAllDrives-$ARCH"
done
lipo -create "$BUILD/EjectAllDrives-arm64" "$BUILD/EjectAllDrives-x86_64" -output "$APP/Contents/MacOS/EjectAllDrives"
cat > "$APP/Contents/Info.plist" <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0"><dict>
<key>CFBundleName</key><string>Eject All Drives</string>
<key>CFBundleDisplayName</key><string>Eject All Drives</string>
<key>CFBundleIdentifier</key><string>com.carlcox.ejectalldrives</string>
<key>CFBundleExecutable</key><string>EjectAllDrives</string>
<key>CFBundleIconFile</key><string>AppIcon</string>
<key>CFBundlePackageType</key><string>APPL</string>
<key>CFBundleShortVersionString</key><string>1.1</string>
<key>CFBundleVersion</key><string>2</string>
<key>LSMinimumSystemVersion</key><string>13.0</string>
<key>NSHighResolutionCapable</key><true/>
<key>NSHumanReadableCopyright</key><string>Created for Carl Cox.</string>
</dict></plist>
PLIST
# Set SIGN_IDENTITY to your Developer ID Application identity for distributable signing.
codesign --force --options runtime --sign "${SIGN_IDENTITY:--}" "$APP"
codesign --verify --deep --strict --verbose=2 "$APP"
printf 'Built: %s\n' "$APP"
