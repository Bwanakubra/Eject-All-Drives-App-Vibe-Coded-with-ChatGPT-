#!/bin/bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
mkdir -p "$ROOT/build/module-cache"
export CLANG_MODULE_CACHE_PATH="$ROOT/build/module-cache"
xcrun swiftc -swift-version 5 "$ROOT/Sources/DiskSafety.swift" "$ROOT/Tests/main.swift" -o "$ROOT/build/SafetyTests"
"$ROOT/build/SafetyTests"
